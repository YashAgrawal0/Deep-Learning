#!/usr/bin/env python
# coding: utf-8

# In[85]:

import pickle
import numpy as np
import math
import matplotlib
import os
matplotlib.use('agg')
import matplotlib.pyplot as plt
# import pandas
import numpy as np
from keras.models import Sequential
from keras.layers import Dense
from keras.layers import LSTM, Dropout
from sklearn.preprocessing import MinMaxScaler
from sklearn.metrics import mean_squared_error

# In[104]:


TRAINING_SAMPLES = 0.8
FEATURES = 1
look_back = 8
op_folder = "/users/home/dlagroup5/wd/Assignment4/Task1/Subtask2/results"


# In[87]:


AP = np.arange(0, 10000)
print(AP.shape)


# In[88]:


# split into train and test sets
train_size = int(len(AP) * TRAINING_SAMPLES)
test_size = len(AP) - train_size
train, test = AP[0:train_size], AP[train_size:len(AP)]
train = np.reshape(train, (train.shape[0], 1))
test = np.reshape(test, (test.shape[0], 1))
print("train: ", train.shape)
print("test: ", test.shape)


# In[93]:


# convert an array of values into a dataset matrix
def create_dataset(dataset, look_back=1):
	dataX, dataY = [], []
	for i in range(len(dataset)-look_back-1):
		a = dataset[i:(i+look_back)]
		dataX.append(a)
		dataY.append(dataset[i + look_back])
	return np.array(dataX), np.array(dataY)


# In[98]:


# reshape into X=t and Y=t+1
trainX, trainY = create_dataset(train, look_back)
testX, testY = create_dataset(test, look_back)
print (trainX.shape, trainY.shape)


# In[106]:


# reshape input to be [samples, time steps, features]
trainX = np.reshape(trainX, (trainX.shape[0], look_back, FEATURES))
testX = np.reshape(testX, (testX.shape[0], look_back, FEATURES))
print (trainX.shape)


# In[ ]:


# create and fit the LSTM network
model = Sequential()
model.add(LSTM(1024, input_shape=(look_back, FEATURES)))
model.add(Dropout(0.1))
model.add(Dense(1, activation="linear"))
model.compile(loss='mean_squared_error', optimizer='adam', metrics=["accuracy"])
model.summary()
model.fit(trainX, trainY, validation_data=[testX, testY], epochs=20, batch_size=4, verbose=1)


print ("after train")
if not os.path.exists(op_folder):
    os.makedirs(op_folder)
model.save_weights(op_folder + "/ap.h5")
print ("Model saved...")

# In[ ]:


# # make predictions
# trainPredict = model.predict(trainX)
# testPredict = model.predict(testX)
# # calculate mean squared error
# print("trainY: ", trainY.shape)
# print("trainPredict: ", trainPredict.shape)
# print("testX: ", testX.shape)
# print("testPredict: ", testPredict.shape)

# trainScore = mean_squared_error(trainY, trainPredict)
# print('Train Score: %.10f MSE' % (trainScore))
# testScore = mean_squared_error(testY, testPredict)
# print('Test Score: %.10f MSE' % (testScore))

# plt.plot(testY, color="red")
# plt.plot(testPredict, color="green")
# plt.savefig("train.jpg")
# plt.show()
# print("Figure saved")

# # In[ ]:


# # shift train predictions for plotting
# trainPredictPlot = np.empty_like(trainX)
# trainPredictPlot[:] = np.nan
# print("trainX: ", trainX.shape)
# print("trainPredictPlot: ", trainPredictPlot.shape)
# trainPredictPlot = trainX
# # shift test predictions for plotting
# testPredictPlot = np.empty_like(testX)
# testPredictPlot[:] = np.nan
# testPredictPlot = testX
# # plot baseline and predictions
# plt.plot(trainPredictPlot)
# plt.plot(testPredictPlot)
# plt.savefig("result.jpg")
# plt.show()

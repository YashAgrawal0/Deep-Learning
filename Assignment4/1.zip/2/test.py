import numpy as np
import math
import matplotlib
import os
import pickle
matplotlib.use('agg')
import matplotlib.pyplot as plt
# import pandas
import numpy as np
from keras.models import Sequential
from keras.layers import Dense
from keras.layers import LSTM, Dropout
from sklearn.preprocessing import MinMaxScaler
from sklearn.metrics import mean_squared_error

FEATURES = 1
look_back = 8
weights_path = "/users/home/dlagroup5/wd/Assignment4/Task1/Subtask2/results/ap.h5"
op_folder = "./results/ap1_graphs";

with open('../../ap_1.pkl', 'rb') as f:
    data = pickle.load(f)

# print(data[0])
# exit()

X = []
sz = len(data)
for i in range(sz):
	X.append((data[i][0]))
	L = len(data[i][0])
	if(L == look_back): continue
	elif(L < look_back):
		pad = np.full((look_back - L), data[i][0][0])
		# print (pad)
		X[i] = (np.concatenate((pad, data[i][0]), axis=None))
	else:
		X[i] = X[i][len(X[i]) - look_back:]
	print(len(X[i]))

X = np.array(X)

print(X)

# print(data[1][1].shape, X[1].shape)
X_data = np.array([np.concatenate((X[i], data[i][1]), axis=None) for i in range(sz)])
print(X_data)

# create and fit the LSTM network
model = Sequential()
model.add(LSTM(1024, input_shape=(look_back, FEATURES)))
model.add(Dropout(0.1))
model.add(Dense(1, activation="linear"))
model.compile(loss='mean_squared_error', optimizer='adam', metrics=["accuracy"])
model.summary()
model.load_weights(weights_path)
print("Weights loaded")

predict_array = np.ndarray.tolist(X_data[0][:look_back])
# predict_array = (data[0][0][:look_back])
# sz = len(data[0][1])
sz = 500
GT = list.copy(predict_array)
# print(GT)
# exit()
for i in range(sz):
	feed = np.array(predict_array[i:(i + look_back)])
	feed = np.reshape(feed, (1, look_back, 1))
	# print(feed.shape)
	# print(feed)
	y_predict = model.predict(feed)
	# print(y_predict[0][0])
	GT.append(int(int(GT[i + look_back - 1]) + 1))
	predict_array.append(y_predict[0][0])
	print("done", i, " / ", sz),
	print("Predict: ", y_predict[0][0])
	# print("GT: ", GT[i + look_back - 1] + 1)
# print(GT)

predict_array = np.array(predict_array)
plt.plot(predict_array, color="red")
plt.plot(GT, color="green")
plt.legend(["Testing data", "Ground truth"])
plt.savefig(op_folder + "/0.jpg")

